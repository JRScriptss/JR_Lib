ItemLabels = {
    ["water"] = "Water bottle",
}