Config = {}

Config.Debug = false -- Adds additional prints and enables all other resource debug options | true or false
Config.Language = 'en' -- Language file name, this means, that it will only load files from script locales folders that contain this name, 
                       -- if this is an invalid locale name on a resource it will default to english

Config.Framework = "esx" 
Config.IsOldESX = false --This option is needed if you are running an older version of ESX
Config.FrameworkResource = "es_extended" -- Framework resource name
--SUPPORTED FRAMEWORK NAMES TO PUT IN: Config.Framework = ""
--[[
    esx
    qbx - (Uncomment qbx_core export in JR_Lib/fxmanifest.lua file)
    ox - (Uncomment ox_core imports in fxmanifest.lua file)
]]

Config.SQLConnector = "oxmysql"
--SUPPORTED SQL CONNECTOR NAMES TO PUT IN: Config.SQLConnector = ""
--[[
    oxmysql
    mysql-async
    ghmattimysql
]]

Config.Inventory = "ox_inventory"
Config.InventoryResource = 'ox_inventory' -- The inventory system folder name that you're using
Config.CarryItemsEnabled = true -- Should the Carry Items system be enabled
--SUPPORTED INVENTORY SCRIPT NAMES TO PUT IN: Config.Inventory = ""
--[[
    esx_inventory
    qb-inventory
    ox_inventory
]]

Config.Target = "ox_target"
Config.TargetResource = 'ox_target' -- The inventory system folder name that you're using
--SUPPORTED TARGET SCRIPT NAMES TO PUT IN: Config.Target  = ""
--[[
    qb-target
    ox_target
    qtarget
]]

Config.ProgessBar = 'ox_lib' -- ox_lib / qb
--SUPPORTED PROGRESS BAR SCRIPT NAMES TO PUT IN: Config.ProgessBar = ""
--[[
    ox_lib - (Uncomment ox_lib import in JR_Lib/fxmanifest.lua file)
    qb
]]

Config.Menu = 'ox_lib'
Config.MenuResource = 'ox_lib' -- The menu system folder name that you're using
--SUPPORTED MENU SCRIPT NAMES TO PUT IN: Config.Menu = ""
--[[
    ox_lib - (Uncomment ox_lib import in JR_Lib/fxmanifest.lua file)
    qb
    nh-context
    esx_menu_default
    esx_context
]]

Config.Input = 'ox_lib'
Config.InputResource = 'ox_lib' -- The input system folder name that you're using
--SUPPORTED INPUT SCRIPT NAMES TO PUT IN: Config.Input = ""
--[[
    ox_lib - (Uncomment ox_lib import in JR_Lib/fxmanifest.lua file)
    qb-input
]]

Config.TextUI = "ox_lib"
Config.TextUIResource = "ox_lib" -- The TextUI system folder name that you're using
--SUPPORTED TEXT UI SCRIPT NAMES TO PUT IN: Config.TextUI = ""
--[[
    ox_lib - (Uncomment ox_lib import in JR_Lib/fxmanifest.lua file)
    okokTextUI
    qb
]]

Config.Poly = "ox_lib"
Config.PolyResource = "ox_lib" -- The Polyzone system folder name that you're using
--SUPPORTED ZONE SCRIPT NAMES TO PUT IN: Config.Poly = ""
--[[
    polyzone
    ox_lib - (Uncomment ox_lib import in JR_Lib/fxmanifest.lua file)
    okokTextUI
    qb
]]

Config.Notifications = "ox_lib"
Config.NotificationsResource = "ox_lib" -- The notification system folder name that you're using
--SUPPORTED NOTIFICATION SCRIPT NAMES TO PUT IN: Config.Notifications = ""
--[[
    ox_lib - (Uncomment ox_lib import in JR_Lib/fxmanifest.lua file)
    qb
    esx
]]

Config.WeatherSync = 'cd_easytime'
--SUPPORTED WEATHER SYNC SCRIPT NAMES TO PUT IN: Config.WeatherSync = ""
--[[
    qb-weathersync
    cd_easytime
]]

Config.Dispatch = 'default'
Config.DispatchResource = 'default' -- The dispatch system resource folder name
--SUPPORTED DISPATCH SCRIPT NAMES TO PUT IN: Config.Dispatch = ""
--[[
    fea-dispatch
    origen_police
    rcore_dispatch
    cd_dispatch
    core_dispatch
    default - standalon version, not recommended for productions servers without changes to the code
    outwalter
    ps-dispatch
    qs-dispatch
]]

Config.Fuel = 'ox_fuel'
Config.FuelResource = 'ox_fuel' -- The fuel system resource folder name
--SUPPORTED FUEL SCRIPT NAMES TO PUT IN: Config.Fuel = ""
--[[
    okokGasStation
    LegacyFuel
    ox_fuel
]]

Config.VehicleKeys = 'JR_Carkeys'
Config.VehicleKeysResource = nil -- The vehicle key system resource folder name
--SUPPORTED VEHICLE KEY SCRIPT NAMES TO PUT IN: Config.VehicleKeys = ""
--[[
    MrNewbVehicleKeys
    okokGarage
    qs-vehiclekeys
    wasabi_carlock
    cd_garage
    qb-vehiclekeys
    JR_Carkeys
]]

Config.Clothing = 'illenium-appearance'
Config.ClothingResource = 'illenium-appearance' -- The clothing system resource folder name
--SUPPORTED CLOTHING SCRIPT NAMES TO PUT IN: Config.Clothing = ""
--[[
    esx_skin
    fivem-appearance
    illenium-appearance
    qb-clothing
]]

Config.SkillMenu = { -- Configuration for skill menu.
    Enabled = true, -- Should the Skill Menu be enabled
    Command = "skills" -- The comand which opens the skill menu. Set this to false to disable it. Skill menu can be also opened by using exports["JR_Lib"]:OpenSkillMenu()
}