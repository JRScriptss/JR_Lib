Dispatch = function(data)
    TriggerClientEvent('fea-dispatch:peuren:alert', -1, data)
end 

return Dispatch