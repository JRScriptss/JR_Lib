Dispatch = function(data)
    TriggerClientEvent('JR_Lib:SendDispatchAlert', -1, data)
end 

return Dispatch