CarKeys = {
    Give = function(veh, plate)
        exports[Config.VehicleKeysResource]:GiveKeyPlate(plate)
    end
}

return CarKeys