CarKeys = {
    Give = function(veh, plate)
        exports[Config.VehicleKeysResource]:givePlayerKeys(plate)
    end
}

return CarKeys