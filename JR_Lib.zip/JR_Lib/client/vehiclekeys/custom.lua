CarKeys = {
    Give = function(veh, plate)
        exports[Config.VehicleKeysResource]:AddKey(plate)
    end
}

return CarKeys