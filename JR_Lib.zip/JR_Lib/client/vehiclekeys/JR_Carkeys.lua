CarKeys = {
    Give = function(veh, plate)
        exports.JR_Carkeys:GiveKeyItem(plate, vehicle)
    end
}

return CarKeys