CarKeys = {
    Give = function(veh, plate)
        exports[Config.VehicleKeysResource]:GiveKeys(veh)
    end
}

RegisterNetEvent('JR_Lib:RemoveVehKeys', function(veh, plate)
    exports[Config.VehicleKeysResource]:RemoveKeys(veh)
end)

return CarKeys