CarKeys = {
    Give = function(veh, plate)
        exports[Config.VehicleKeysResource]:addKey(plate)
    end
}

RegisterNetEvent('JR_Lib:RemoveVehKeys', function(veh, plate)
    exports[Config.VehicleKeysResource]:RemoveKeys(veh)
    exports[Config.VehicleKeysResource]:removeKey(plate)
end)

return CarKeys